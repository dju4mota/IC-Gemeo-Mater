# ic-basico > 2024-04-12 2:45pm
https://universe.roboflow.com/ic-14cop/ic-basico

Provided by a Roboflow user
License: CC BY 4.0

