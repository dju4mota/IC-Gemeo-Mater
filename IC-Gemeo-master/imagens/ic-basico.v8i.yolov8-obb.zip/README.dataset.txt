# ic-basico > 2024-04-23 8:52pm
https://universe.roboflow.com/ic-14cop/ic-basico

Provided by a Roboflow user
License: CC BY 4.0

