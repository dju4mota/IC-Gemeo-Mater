# ic-basico > 2024-03-20 4:04pm
https://universe.roboflow.com/ic-14cop/ic-basico

Provided by a Roboflow user
License: CC BY 4.0

