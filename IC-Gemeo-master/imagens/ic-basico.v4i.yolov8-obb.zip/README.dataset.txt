# ic-basico > 2024-03-26 3:58pm
https://universe.roboflow.com/ic-14cop/ic-basico

Provided by a Roboflow user
License: CC BY 4.0

