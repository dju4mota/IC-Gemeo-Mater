# IC > 2023-10-24 10:09pm
https://universe.roboflow.com/ic-14cop/ic-noaed

Provided by a Roboflow user
License: CC BY 4.0

